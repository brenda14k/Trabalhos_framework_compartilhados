#[Tabela (nome:'produtos')]

class Produtos{
    #[Coluna]

    public ?int $id=null;

     #[Coluna]

    public string $nome;

        #[Coluna]

    public string $email;

}