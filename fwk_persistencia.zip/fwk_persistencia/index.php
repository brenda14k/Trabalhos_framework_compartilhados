<?php

require_once 'Atributos/Tabela.php';
require_once 'Atributos/Coluna.php';
require_once 'Entidades/Usuarios.php';
require_once 'Framework/fwkPersist.php';
$pdo = new PDO("mysql: host=localhost;dbname=sistema_teste; charset=utf8mb4", "root","");
$usuario = new Usuario();
$usuario->nome = "Alice castanho";
$usuario->email = "alice63@gmail.br";
$fwk = new fwkPersist($pdo);

$fwk->save($usuario);
$registros=$fwk->listAll(Usuario::class);
echo "Registro salvo com sucesso no banco!<br>";
foreach ($registros as $registro) {
    echo "Nome: ".$registro->nome . "<br>";
     echo "Email: ".$registro->email . "<hr>";
}