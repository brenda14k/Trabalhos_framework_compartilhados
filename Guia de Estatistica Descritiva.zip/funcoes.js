let dados=[1,3,21,24,5,1,13,2,17,3];
const media=document.getElementById("media");
const mediana=document.getElementById("mediana");
const moda=document.getElementById("moda");
const variancia=document.getElementById("variancia");
const desPadrao=document.getElementById("desvPadrao");
const coefVariacao=document.getElementById("coefVariacao");
function calcularMedia(){
 }

function calcularMediana(){
}
function calcularModa(){
}
function calcularVariancia(){
}
function calcularDesvioPadrao(){
}
function calcularCoeficienteDeVariacao(){
}
media.innerHTML=calcularMedia().toFixed(2);
mediana.innerHTML=calcularMediana();
moda.innerHTML=calcularModa();
variancia.innerHTML=calcularVariancia();
desPadrao.innerHTML=calcularDesvioPadrao().toFixed(2);
coefVariacao.innerHTML=calcularCoeficienteDeVariacao().toFixed(2)+"%";